package com.te.hibernate.jpa.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="emp_table")
public class Employee implements Serializable{
     @Id
     @GeneratedValue(strategy=GenerationType.IDENTITY)
     @Column(name="emp_id")
	private int empId;
     @Column(name="emp_name")
    private String empName;
     @Column(name="emp_PhoneNumber")
    private long empPhoneNumber;
	public Employee( String empName, long empPhoneNumber) {
		super();
	
		this.empName = empName;
		this.empPhoneNumber = empPhoneNumber;
	}
	public Employee() {
		super();
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public long getEmpPhoneNumber() {
		return empPhoneNumber;
	}
	public void setEmpPhoneNumber(long empPhoneNumber) {
		this.empPhoneNumber = empPhoneNumber;
	}
	
	


}
    
