package com.te.springAnnotation.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.te.springAnnotation.config.AnnotationConfig;

public class EmployeeTest {
public static void main(String[] args) {
	
	ApplicationContext context=new AnnotationConfigApplicationContext(AnnotationConfig.class);
	Employee employee=context.getBean("employee",Employee.class);
	System.out.println(employee);
}
}
