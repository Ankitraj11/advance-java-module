package com.te.springAnnotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.te.springAnnotation.beans.Employee2;
import com.te.springAnnotation.beans.Laptop;


@Configuration

public class EmployeeConfig {

	@Bean
	public Laptop getLaptop() {
//		Laptop laptop=new Laptop();
//		laptop.setL_id(101);
//		laptop.setL_name("HP");
//		return laptop;
		
		Laptop laptop=new Laptop();
	    laptop.setL_id(101);
	    laptop.setL_name("HP");
	    return laptop;
	}
	
	@Bean
	public Laptop getLaptop1() {
		Laptop laptop=new Laptop();
		laptop.setL_id(120);
		laptop.setL_name("Dell");
		return laptop;
	}
	
	@Bean("employee")
	public Employee2 getEmployee() {
		Employee2 employee=new Employee2();
		employee.setE_id(201);
		employee.setE_name("Abhiskek");
		return employee;
		
		
	}
	
}
