package com.te.springAnnotation.beans;

import java.io.Serializable;

import lombok.Data;
@Data
public class Laptop implements Serializable {
    
	private int l_id;
    private String l_name;
}
