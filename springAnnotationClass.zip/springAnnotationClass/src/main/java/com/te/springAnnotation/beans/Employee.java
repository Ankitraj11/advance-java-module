package com.te.springAnnotation.beans;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;
@Data
@Component
public class Employee implements Serializable {
      @Value("201")
	  private int eId;
      @Value("Anil")
	  private String eName;
      
      @Autowired
	  private AddressEmp addressEmp;
}
