package com.te.springAnnotation.beans;

import java.io.Serializable;

import lombok.Data;
@Data
public class Address implements Serializable {

	private  int houseNo;
	  
}
