package com.te.springAnnotation.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.te.springAnnotation.beans.Employee2;
import com.te.springAnnotation.config.EmployeeConfig;

public class EmployeeTest {
public static void main(String[] args) {
	ApplicationContext context=new AnnotationConfigApplicationContext(EmployeeConfig.class);
  Employee2 employee=context.getBean("employee",Employee2.class);
    System.out.println(employee);
}
}
