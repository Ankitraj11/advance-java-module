package com.te.springAnnotation.beans;

import java.io.Serializable;

import lombok.Data;
@Data
public class Employee2 implements Serializable {
   private int e_id;
   private String e_name;
}
