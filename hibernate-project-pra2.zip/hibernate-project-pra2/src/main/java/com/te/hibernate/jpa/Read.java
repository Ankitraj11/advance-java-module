package com.te.hibernate.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.te.hibernate.jpa.beans.Student;

public class Read {

	
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("StudentUnit01");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
	
		
		String query=" from Student ";
		Query readQuery=entityManager.createQuery(query);
		List list=readQuery.getResultList();
		
		for(Object queryL:list) {
			Student student=(Student)queryL;
			System.out.println(student.getStudentId());
			System.out.println(student.getStudentName());
			
		}
		
	}
}
