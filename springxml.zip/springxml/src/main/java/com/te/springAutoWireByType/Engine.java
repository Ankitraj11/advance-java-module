package com.te.springAutoWireByType;

import java.io.Serializable;

import lombok.Data;
@Data
public class Engine  implements Serializable{

	  private String engineName;
	  private String engineCc;
}
