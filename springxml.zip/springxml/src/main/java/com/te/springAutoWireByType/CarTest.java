package com.te.springAutoWireByType;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.te.springAutoWireByType.Car;

public class CarTest {

	public static void main(String[] args) {
		
		ApplicationContext context= new ClassPathXmlApplicationContext("carEnigineAutoWire.xml");
	    Car car=context.getBean("car",Car.class);
		System.out.println(car);
	}
}
