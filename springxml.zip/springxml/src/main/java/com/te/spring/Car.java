package com.te.spring;

import java.io.Serializable;

import lombok.Data;
@Data
public class Car implements Serializable {

	private String carNo;
	private String carName;
	private Engine engine;
}
