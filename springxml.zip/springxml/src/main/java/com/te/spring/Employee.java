package com.te.spring;

import java.io.Serializable;

import lombok.Data;
@Data
public class Employee implements Serializable {

	private int id;
	private String name;
	private String address;
	public Employee(int id, String name, String address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
