package com.te.springAutoWireConstructor;

import java.io.Serializable;

import lombok.Data;

@Data
public class Engine implements Serializable {

	  private String engineName;
	  private String engineCc;
}
