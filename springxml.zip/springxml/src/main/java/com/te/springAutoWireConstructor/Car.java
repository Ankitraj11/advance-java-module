package com.te.springAutoWireConstructor;

import java.io.Serializable;

import lombok.Data;
@Data
public class Car implements Serializable {

	
	private String carNo;
	private String carName;
	private  Engine engine;
	public Car(Engine engine) {
		super();
		this.engine = engine;
	}
	
    
}
