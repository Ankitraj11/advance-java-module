package com.te.studentmanag;

public class App {

}
