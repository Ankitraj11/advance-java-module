package com.te.springcoreusinginterface.main;


public interface Address {
     public final static int  HOUSENO=12;
    
	void showAddress();
	
}
