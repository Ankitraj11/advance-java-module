package com.te.springcoreusinginterface.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.te.springcoreusinginterface.main.Address;
import com.te.springcoreusinginterface.main.LocalAddress;
import com.te.springcoreusinginterface.main.OfficialAddress;

@Configuration
public class AddressConfig {

	@Bean("localAddress")
	public Address getLocalAddress() {
		Address address = new LocalAddress();
		return address;

	}

	@Bean("globalAddress")
	public Address getOffAddress() {
		Address address = new OfficialAddress();
		return address;
	}
}
