package com.te.springcoreusinginterface.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.te.springcoreusinginterface.beans.Employee;
import com.te.springcoreusinginterface.config.AllConfig;

public class Test {
	
	
	public void getEmployee1() {

		ApplicationContext context=new AnnotationConfigApplicationContext(AllConfig.class);
		Employee employee=context.getBean("getEmployee2",Employee.class);
		System.out.println(employee);
		employee.setAddress(new OfficialAddress());
		System.out.println(employee);
		employee.getAddress().showAddress();
		
		
	}
public static void main(String[] args) {
	
	   Test test=new Test();
	   System.out.println("enter employee id");
	   Scanner scanner=new Scanner(System.in);
	   int id=scanner.nextInt();
	   test.getEmployee1();
	
	
}
}




