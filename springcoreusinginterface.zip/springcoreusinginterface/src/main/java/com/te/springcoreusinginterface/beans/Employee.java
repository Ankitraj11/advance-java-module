package com.te.springcoreusinginterface.beans;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.te.springcoreusinginterface.main.Address;

import lombok.Data;

@Data
@Component
public class Employee implements Serializable {

   
	private int empId;
	private String empName;
	
	
	
     @Autowired
     @Qualifier("localAddress")
	private Address address;
	
}
