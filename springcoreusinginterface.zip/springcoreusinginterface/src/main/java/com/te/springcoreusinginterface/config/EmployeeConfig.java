package com.te.springcoreusinginterface.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.te.springcoreusinginterface.beans.Employee;

@Configuration
public class EmployeeConfig {

	@Bean
	public Employee getEmployee1() {
		Employee employee=new Employee();
		employee.setEmpId(101);
		employee.setEmpName("Ankit");
		
		return employee;
	}
	
	@Bean("getEmployee2")
	public Employee getEmployee2() {
		Employee employee=new Employee();
		employee.setEmpId(102);
		employee.setEmpName("Kartik");
	     return employee;
	}
	
}
