package com.te.springcoreusinginterface.main;

import org.springframework.stereotype.Component;

@Component
public class LocalAddress implements Address {

	@Override
	public void showAddress() {
		// TODO Auto-generated method stub
		System.out.println("Local address ="+Address.HOUSENO);
	}

	

	

}
