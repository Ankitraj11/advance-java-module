package com.te.hibernate.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.hibernate.jpa.beans.Director;
import com.te.hibernate.jpa.beans.Movie;

public class App {

	
	public static void main(String[] args) {
		   
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("DirectorUnit01");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		
		
	 	Director director=new Director();
		director.setDirectorName("Rohit Setty");
	      
	        
	      
	     Movie movie1=new Movie();
	     movie1.setActor("Aaamir Khan");
	     movie1.setMovieName("singham");
	     
	      movie1.setDirector(director);
	   
	     
	    
	     
	     
	     
	     
	    
	    
	 	entityTransaction.begin();
		
	     	
	     	entityManager.persist(movie1);
		entityTransaction.commit();
		
		
	}
}
