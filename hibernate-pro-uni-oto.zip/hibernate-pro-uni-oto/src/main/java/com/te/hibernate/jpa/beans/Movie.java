package com.te.hibernate.jpa.beans;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name="movie")

public class Movie implements Serializable { 
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    
	@Column(name="movie_id")
      private int movieId;
     
     @Column(name="movie_name")
     private String movieName;
     
     @Column(name="actor")
      private String actor;

     @OneToOne(cascade = CascadeType.ALL)
     @JoinColumn(name="dir_id")
     private Director director;

	public Movie(int movieId, String movieName, String actor) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.actor = actor;
	}

	public Movie() {
		super();
	}

	
}
