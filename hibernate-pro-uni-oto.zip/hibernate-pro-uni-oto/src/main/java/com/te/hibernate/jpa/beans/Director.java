package com.te.hibernate.jpa.beans;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name="director")
public class Director implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="director_id")
	private int directorId;
	
    @Column(name="director_name")
	private String directorName;

   

      
	

	public Director() {
		super();
	}






	public Director(int directorId, String directorName) {
		super();
		this.directorId = directorId;
		this.directorName = directorName;
	}



}
