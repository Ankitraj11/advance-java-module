package com.te.hibernate2.sample;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
    	EntityManagerFactory factory=Persistence.createEntityManagerFactory("CartUnit01");
    	EntityManager manager=factory.createEntityManager();
         EntityTransaction transaction=manager.getTransaction();	
        
    Products products=new Products();
    products.setProductName("bag");
     products.setProductPrice(1500);
  
     Products products1=new Products();
     products1.setProductName("laptop");
      products1.setProductPrice(700000);
      
     
       Products products2=new Products();
       products2.setProductName("Shoes");
       products2.setProductPrice(1200);
       Products products3=new Products();
       products3.setProductName("Cap");
       products3.setProductPrice(120);
       Products products4=new Products();
       products4.setProductName("Cap");
       products4.setProductPrice(120);
     
    
  
    Cart cart=new Cart();
    cart.setCartName("cart1");
         
   
    products.setCart(cart);
    products2.setCart(cart);
    products1.setCart(cart);
    products3.setCart(cart);
    products4.setCart(cart);
    manager.find(Cart.class, 1);	
    
     
      
     //manager.persist(cart);
     
       
       List<Products> productsList2=new ArrayList<Products>();
       productsList2.add(products1);
       productsList2.add(products2);
       productsList2.add(products3);
       productsList2.add(products4);
       
       cart.setProductList(productsList2);
          
       
       
      transaction.begin();
      manager.persist(cart);
       
     
      transaction.commit();
    }
}
