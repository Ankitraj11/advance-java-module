package com.te.junit;

public class MathUtils {
	public int add(int a,int b) {
		
		int c=a+b;
		return c;
	}
	
	public int divide(int c,int d) {
		
		return (c/d);
	}
}
