
package com.te.junit.mathutils.MathUtils;

import static org.junit.Assume.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import javax.management.DescriptorKey;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import com.te.junit.MathUtils;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MathUtilsTest {
    MathUtils mathUtils=null;
	@Disabled
	@Test
	public void addTest() {
	 boolean isServerDown=true;
	// assumeFalse(isServerDown);
	 assumeTrue(isServerDown);
		
		//	MathUtils mathUtils=new MathUtils();
		assertEquals(10, mathUtils.add(5,5));
		
	}
	
	@Test
	public void divideTest() {
//		MathUtils mathUtils=new MathUtils();
		assertThrows(ArithmeticException.class, ()->mathUtils.divide(10, 0));
		
	}
	@BeforeEach
	public void beforeEach() {
		 mathUtils=new MathUtils();
	}
	@AfterEach
	public void afterEach() {
		 
		System.out.println("after each");
	}
	
	@BeforeAll
	public void beforeAll() {
		System.out.println("befoer all");
	}
	
	@AfterAll
	public void afterAll() {
		System.out.println("after all");
	}
}
