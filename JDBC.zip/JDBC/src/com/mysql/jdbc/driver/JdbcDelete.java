package com.mysql.jdbc.driver;
//imort jdbc api

import java.sql.*;
import javax.sql.*;

public class JdbcDelete {
public static void main(String[] args) {
	Connection connection=null;
	try {
		//2.Load and register JDBC driver
		Class.forName("com.mysql.jdbc.Driver");
		//3 .establish the connection with database
		String db_name="Student";
		String url ="jdbc:mysql://localhost:3306/"+db_name;;
		String username="root";
		String password="root";
		
		
		try {
	connection		 = DriverManager.getConnection(url,username,password);
		
		    if(!connection.isClosed()) {
		    	System.out.println("connection establised");
		    	
		    }
		    else {
		    	System.out.println("connection not estalside");
		    	
		    	
		    }
		    
		    //4.create statement
		    Statement statement=connection.createStatement();
		    //5. write a query
		    
		    String query="delete   from student  where s_id=2";
		        boolean execute= statement.execute(query);
		    // 6 process the result
		    System.out.println(execute);     
		    
		    
		    //6. process the result
		   // statement.execute(query)
		  //  statement.executeUpdate(query);
		  //  statement .executeQuery(query))
		    
		   // boolean execute = statement.execute(query);
		   // System.out.println(execute);
		    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		//7. connection close
//		connection=null;
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}
