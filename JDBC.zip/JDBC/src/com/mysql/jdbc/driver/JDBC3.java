package com.mysql.jdbc.driver;
//imort jdbc api

import java.sql.*;
import javax.sql.*;

public class JDBC3 {
public static void main(String[] args) {
	Connection connection=null;
	try {
		//2.Load and register JDBC driver
		Class.forName("com.mysql.jdbc.Driver");
		//3 .establish the connection with database
		String db_name="Student";
		String url ="jdbc:mysql://localhost:3306/"+db_name;;
		String username="root";
		String password="root";
		
		
		try {
	connection		 = DriverManager.getConnection(url,username,password);
		
		    if(!connection.isClosed()) {
		    	System.out.println("connection establised");
		    	
		    }
		    else {
		    	System.out.println("connection not estalside");
		    	
		    	
		    }
		    
		    //4.create statement
		    Statement statement=connection.createStatement();
		    //5. write a query
		    
		    String query="select * from student";
		    PreparedStatement preparedStatement=connection.prepareStatement(query);
		  
		    // 6 process the result
		    ResultSet executeQuery =preparedStatement.executeQuery();
		    while(executeQuery.next()) {
		    	System.out.print(" "+executeQuery.getInt(1));
		    	System.out.print(" "+executeQuery.getString(2));
		    	System.out.print("  "+executeQuery.getInt(3));
		      System.out.println();
		    }
		    
		    //6. process the result
		   // statement.execute(query)
		  //  statement.executeUpdate(query);
		  //  statement .executeQuery(query))
		    
		   // boolean execute = statement.execute(query);
		   // System.out.println(execute);
		    
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally {
		//7. connection close
//		connection=null;
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
}
