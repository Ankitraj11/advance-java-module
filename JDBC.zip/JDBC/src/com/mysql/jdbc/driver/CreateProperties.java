package com.mysql.jdbc.driver;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class CreateProperties {
public static void main(String[] args) {
	Properties properties=new Properties();
	properties.setProperty("url", "jdbc:mysql://localhost:3306/student");
	properties.setProperty("username", "root");
	properties.setProperty("password", "root");
	try {
		FileOutputStream fileOutputStream=new FileOutputStream("db.properties");
	      try {
			properties.store(fileOutputStream, "this is my credenital");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
 	
}
}
