package com.mysql.jdbc.driver;
//imort jdbc api

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

import javax.sql.*;

public class JDBC5 {
public static void main(String[] args) {
	Connection connection=null;
	try {
		//2.Load and register JDBC driver
		Class.forName("com.mysql.jdbc.Driver");
		//3 .establish the connection with database
		
//		Properties properties=new Properties();
//		try {
//			FileInputStream fileInputStream=new FileInputStream("db.properties");
//		    try {
//				properties.load(fileInputStream);
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		} catch (FileNotFoundException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//		String url=properties.getProperty("url");
//		String username=properties.getProperty("username");
//		String password=properties.getProperty("password");
//		
//		System.out.println(url +" "+username+" " +password);
//		try {
//			connection=DriverManager.getConnection(url,username,password);
//		} catch (SQLException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		
		
		
				String db_name="Student";
	String url ="jdbc:mysql://localhost:3306/"+db_name;;
		String username="root";
		String password="root";
		
		
		try {
	connection		 = DriverManager.getConnection(url,username,password);
		
		    if(!connection.isClosed()) {
		    	System.out.println("connection establised");
		    	
		    }
		    else {
		    	System.out.println("connection not establiswd");
		    	
		    }
		    
		    //4.create statement
		    Statement statement=connection.createStatement();
		    //5. write a query
		    
		  //4.create callableStatement
	    	//5.write a query
   	String query="call select_student()";
	    	CallableStatement prepareCall=connection.prepareCall(query);
	    	
//		    //6. process the result
	    	ResultSet executeQuery=prepareCall.executeQuery();
	    	while(executeQuery.next())
    	{
	    		System.out.println(executeQuery.getInt(1)+"\n");
	    		System.out.println(executeQuery.getString(1));
	    		
	    	}
		   // statement.execute(query)
		  //  statement.executeUpdate(query);
		  //  statement .executeQuery(query))
		    
		   // boolean execute = statement.execute(query);
		   // System.out.println(execute);
		    
		} catch (SQLException e) {
	
			e.printStackTrace();
		}
	} catch (ClassNotFoundException e) {
		
		e.printStackTrace();
	}
	finally {
		//7. connection close
//		connection=null;
//		try {
//			connection.close();
//		} catch (SQLException e) {
//			
//			e.printStackTrace();
		}
	}
}

