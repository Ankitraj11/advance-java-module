package com.te.hibernate.jpa.beans;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="subject")
public class Subject implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="subject_id")
	private int subjectId;
    @Column(name="subject")
	private String subject;
 
    @ManyToOne(cascade = CascadeType.ALL)
    private Student student;
    public int getSubjectId() {
	return subjectId;
}
public void setSubjectId(int subjectId) {
	this.subjectId = subjectId;
}
public String getSubject() {
	return subject;
}
public void setSubject(String subject) {
	this.subject = subject;
}
  
  
 
  
  

public Student getStudent() {
	return student;
}
public void setStudent(Student student) {
	this.student = student;
}
  
  
  
   
   
   
	
}
