package com.te.hibernate.jpa.beans;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int studentId;
    
    @Column(name="student_name")
	private String studentName;
    @Column(name="std")
	private String std;
    @Column(name="rollNo")
	private int rollNo;
    @OneToMany( cascade= CascadeType.ALL)
	private List<Subject> subList;
	public Student(int studentId, String stduentName, String std, int rollNo) {
		super();
		this.studentId = studentId;
		this.studentName = stduentName;
		this.std = std;
		this.rollNo = rollNo;
	}
	
	
	public Student() {
		super();
	}


	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStduentName() {
		return studentName;
	}
	public void setStduentName(String stduentName) {
		this.studentName = stduentName;
	}
	public String getStd() {
		return std;
	}
	public void setStd(String std) {
		this.std = std;
	}
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	
	

	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	public List<Subject> getSubList() {
		return subList;
	}


	public void setSubList(List<Subject> subList) {
		this.subList = subList;
	}
	
	
	
}
