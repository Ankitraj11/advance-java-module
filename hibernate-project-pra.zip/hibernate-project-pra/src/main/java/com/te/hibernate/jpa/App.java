package com.te.hibernate.jpa;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.te.hibernate.jpa.beans.Student;
import com.te.hibernate.jpa.beans.Subject;

public class App {

  public static void main(String[] args) {
	
	  EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("StudentUnit01");
	    EntityManager entityManager=entityManagerFactory.createEntityManager();
	    EntityTransaction entityTransaction=entityManager.getTransaction();
	    
	    Subject subject1=new Subject();
	    subject1.setSubject("Physics");
	  
	    Subject subject2=new Subject();
	    subject2.setSubject("Chemistry");
	  
	    Subject subject3=new Subject();
	    subject3.setSubject("Maths");
	  
	    Subject subject4=new Subject();
	    subject4.setSubject("English");
	  
	  List<Subject> subList=new ArrayList<Subject>();
	  subList.add(subject1);
	  subList.add(subject2);
	  subList.add(subject3);
	  subList.add(subject4);
	  
	  
	  Student student=new Student();
	  student.setStduentName("Ankit");
	  student.setRollNo(20);
       student.setSubList(subList);
       
       subject1.setStudent(student);
       subject2.setStudent(student);
       subject3.setStudent(student);
       subject4.setStudent(student);
       
      entityTransaction.begin();
      entityManager.persist(student);
      entityTransaction.commit();
	  
}
	
    
}
