package com.te.hibernate2.sample;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="cart")
public class Cart  implements Serializable{
    @Id
    @Column(name="car_no")
	private int cartNo;
	
   @OneToMany(cascade = CascadeType.ALL) 
   private List<Products> productList;
   
	
	
}
