package com.te.hibernate2.sample;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       
    	EntityManagerFactory factory=Persistence.createEntityManagerFactory("CartUnit01");
    	EntityManager manager=factory.createEntityManager();
    	
    	
    Products products=new Products();
    products.setProductName("bag");
    products.setProductName("laptop");
    products.setProductName("trimmer");
    
    List<Products> productsList=new ArrayList<Products>();
    productsList.add(products);
    
    Cart cart=new Cart();
    
    	
    }
}
