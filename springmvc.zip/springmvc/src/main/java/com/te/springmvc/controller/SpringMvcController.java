package com.te.springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.te.springmvc.beans.EmployeeDetails;

@Controller
public class SpringMvcController {

	@RequestMapping(path = "/home")
	public String home() {
		return "/WEB-INF/views/home.jsp";
	}
	@RequestMapping(path="/data1")
	public String data(Model model) {
	    model.addAttribute("name", "ankit");	
		return "/WEB-INF/views/data.jsp";
	}
	@RequestMapping(path="/data")
	public String friendList(ModelMap map ) {
		List<String> list=new ArrayList<String>();
		list.add("Aaamir khan");
		list.add("Shahruk khan");
		list.add("Salman Khan");
		list.add("Akshay Kumar");
		
		map.addAttribute("heroes", list);
		return "/WEB-INF/views/data.jsp";
		
		
	}
	@RequestMapping(path = "/login")
	public String login() {
		return "/WEB-INF/views/login.jsp";
	}
	
	@RequestMapping(path="/getData",method = RequestMethod.POST)
	public String getData(HttpServletRequest req,Model model) {
		String email=req.getParameter("email");
		String pass=req.getParameter("pass");
		model.addAttribute("email", email);
		model.addAttribute("pass", pass);
		return "/WEB-INF/views/getData.jsp";
	}
	
	@RequestMapping(path="/getData2")
	public String getDataTwo(@RequestParam String email,@RequestParam String pass ,Model model) {
		
		model.addAttribute("email", email);
		model.addAttribute("pass", pass);
		return "/WEB-INF/views/getData.jsp";
	}
	@RequestMapping(path="/getData3")
	public String getDataThree( String email, String pass ,Model model) {
		
		model.addAttribute("email", email);
		model.addAttribute("pass", pass);
		return "/WEB-INF/views/getData.jsp";
	}

	@RequestMapping(path="/userDetails",method = RequestMethod.POST)
	public String  getDataFour(EmployeeDetails details,ModelMap model) {
		
		model.addAttribute("data", details);
		return "/WEB-INF/views/userDetails.jsp";
	}
	@RequestMapping(path="/model",method = RequestMethod.POST)
	public ModelAndView getDataFive(ModelAndView addView) {
		addView.addObject("name","ankit");
		addView.setViewName("WEB-INF/views/modelView.jsp");
		
		
		return addView;
		
	}
	
	

}
