package com.te.empwebapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.te.empwebapp.beans.EmployeeDetails;
import com.te.empwebapp.service.EmployeeService;

@Controller
public class SpringController {

	@Autowired
	private EmployeeService service;

	@GetMapping("/login")
	public String getData() {

		return "loginForm";
	}

	@GetMapping("/add")
	public String addForm() {
		return "addForm";
	}

	@PostMapping("/login")
	public String getLoginForm(int id, String pass, ModelMap map) {

		EmployeeDetails details = service.login(id, pass);
		if (details != null) {
			map.addAttribute("data", details.getName());
			return "welcome";
		} else {
			map.addAttribute("errMsg", "invalid");
			return "loginForm";
		}

	}

	@PostMapping("/add")
	public String addData(EmployeeDetails details, ModelMap map) {
		if (service.addData(details)) {
			map.addAttribute("msg", "data inserted ");

		} else {
			map.addAttribute("error", "something went wrong");

		}
		return "addForm";
	}
	
	@GetMapping("/getForm")
	public String getEmployee() {
		return "getForm";
		
	}
	@PostMapping("/getDetails")
	public String  getDetails(int id,ModelMap map) {
		 EmployeeDetails details=service.getDetails(id);
		 if(details!=null) {
			 map.addAttribute("data", details);
		 }
		 else {
			 map.addAttribute("error", "data not found for id"+id);
			    
		 }
		 return "getForm";
		 
		
	}
}
