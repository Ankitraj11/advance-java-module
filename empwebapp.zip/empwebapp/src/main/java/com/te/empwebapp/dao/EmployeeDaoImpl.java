package com.te.empwebapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.springframework.stereotype.Repository;

import com.te.empwebapp.beans.EmployeeDetails;
@Repository
public class EmployeeDaoImpl implements EmployeeDao{

	@Override
	public EmployeeDetails login(int id, String pass) {
		// TODO Auto-generated method stub
       
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("EmployeeUnit01");
		EntityManager manager =factory.createEntityManager();
		EmployeeDetails details=manager.find(EmployeeDetails.class,id);
		if(details!=null) {
			if(details.getPassword().equals(pass)) {
			   
				return details;
			   
		}
			
	}
     return null;
	
	}

	@Override
	public boolean addData(EmployeeDetails details) {
		// TODO Auto-generated method stub
	    EntityTransaction transaction=null;
		 boolean isAdded=false;
		 try {
			EntityManagerFactory factory =Persistence.createEntityManagerFactory("EmployeeUnit01");
			 EntityManager manager =factory.createEntityManager();
			 transaction=manager.getTransaction();
			 transaction.begin();
			 manager.persist(details);
			 isAdded=true;
			 transaction.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if(transaction!=null) {
				transaction.rollback();
			}
			e.printStackTrace();
			
		}
	  return isAdded;	
	}

	@Override
	public EmployeeDetails getDetails(int id) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("EmployeeUnit01");
		EntityManager manager=factory.createEntityManager();
	   EmployeeDetails details=	manager.find(EmployeeDetails.class, id);
		if(details!=null) {
			return details;
		}
		
	        return null;
		
	}
	
}
