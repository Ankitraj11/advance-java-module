package com.te.springrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.te.springrest.beans.Employee;
import com.te.springrest.dao.EmployeeDao;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao;

	@Override
	public Employee getData(int id) {
		// TODO Auto-generated method stub
		return dao.getData(id);
	}

	@Override
	public boolean deleteData(int id) {
		// TODO Auto-generated method stub
		if (id < 0) {
			return false;
		} else {
			return dao.deleteData(id);
		}
	}

	@Override
	public boolean addData(Employee employee) {
		// TODO Auto-generated method stub

		return dao.addData(employee);
	}

	@Override
	public boolean updateData(int id, Employee employee) {
		// TODO Auto-generated method stub
		return dao.updateData(id, employee);
	}

	@Override
	public List<Employee> seeAll() {
		// TODO Auto-generated method stub
		return dao.seeAll();
	}

}
