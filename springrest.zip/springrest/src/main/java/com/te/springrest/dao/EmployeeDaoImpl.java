package com.te.springrest.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.te.springrest.beans.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public Employee getData(int id) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("StudentUnit01");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();

		Employee employee = manager.find(Employee.class, id);
		if (employee != null) {
			return employee;
		} else {
			return null;
		}
	}

	@Override
	public boolean deleteData(int id) {
		// TODO Auto-generated method stub
		boolean isRemoved = false;
		EntityTransaction transaction = null;

		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("StudentUnit01");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			Employee employee = manager.find(Employee.class, id);
			if (employee != null) {
				transaction.begin();
				manager.remove(employee);
				transaction.commit();
				isRemoved = true;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			transaction.rollback();
			e.printStackTrace();
		}
		return isRemoved;
	}

	@Override
	public boolean addData(Employee employee) {
		// TODO Auto-generated method stub
		boolean isAdded = false;
		EntityTransaction transaction = null;

		try {
			EntityManagerFactory factory = Persistence.createEntityManagerFactory("StudentUnit01");
			EntityManager manager = factory.createEntityManager();
			transaction = manager.getTransaction();

			transaction.begin();
			manager.persist(employee);
			transaction.commit();
			isAdded = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			transaction.rollback();
			e.printStackTrace();
		}
		return isAdded;

	}

	@Override
	public boolean updateData(int id, Employee employee) {
		// TODO Auto-generated method stub

		boolean isUpdated = false;
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("StudentUnit01");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();

		Employee employee2 = manager.find(Employee.class, id);
		if (employee2 != null) {

			employee2.setName(employee.getName());
			employee2.setId(employee.getId());
			employee2.setPassword(employee.getPassword());
			employee2.setDob(employee.getDob());

			transaction.begin();
			manager.persist(employee2);
			transaction.commit();
			isUpdated = true;
		}
		return isUpdated;

	}

	@Override
	public List<Employee> seeAll() {
		// TODO Auto-generated method stub

		String query = "from Employee";
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("StudentUnit01");
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();

		String queryForFetch = "from Employee";
		Query queryForResult = manager.createQuery(queryForFetch);
		transaction.begin();
		List<Employee> emplList = queryForResult.getResultList();
		return emplList;
	}

}
