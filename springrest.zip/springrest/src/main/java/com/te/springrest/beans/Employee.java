package com.te.springrest.beans;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "employee")
public class Employee implements Serializable {

	@Id

	@Column
	private int id;
	@Column
	private String name;
	@Column
	private String dob;
	@Column
	// @JsonIgnore
	private String password;

}
