package com.te.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.te.springrest.beans.Employee;
import com.te.springrest.beans.EmployeeResponse;
import com.te.springrest.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@GetMapping("/getAll")
	public EmployeeResponse seeAll() {

		EmployeeResponse response = new EmployeeResponse();
		List<Employee> emList = service.seeAll();
		if (emList != null) {

			response.setDescription("data are");
			response.setEmployees(emList);
			response.setMsg("success");
			response.setStatus(200);

		} else {
			response.setMsg("failure");
		}
		return response;

	}

	@PutMapping("/employee/{id}")
	public EmployeeResponse updateData(@PathVariable int id, @RequestBody Employee employee) {
		EmployeeResponse response = new EmployeeResponse();
		if (service.updateData(id, employee)) {
			response.setDescription("data updated successfully");
			response.setEmployee(employee);
			response.setMsg("success");
			response.setStatus(200);
		} else {

			response.setDescription("something went wrong");

			response.setMsg("failure");
			response.setStatus(404);
		}
		return response;
	}

	@RequestMapping(path = "/getData", produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public EmployeeResponse getData(int id) {
		EmployeeResponse response = new EmployeeResponse();
		Employee employee = service.getData(id);
		if (employee != null) {
			response.setStatus(200);
			response.setDescription("the data of id" + id);
			response.setMsg("success");
			response.setEmployee(employee);
		} else {

			response.setStatus(404);
			response.setMsg("failure");

		}

		return response;
	}

	@DeleteMapping("employee/{id}")
	public EmployeeResponse deleteData(@PathVariable int id) {
		EmployeeResponse response = new EmployeeResponse();

		if (service.deleteData(id)) {

			response.setDescription("data deleted successfully");
			response.setMsg("success");
			response.setStatus(200);

		} else {
			response.setDescription("someting wentn wrong");
			response.setMsg("failure");
			response.setStatus(404);
		}
		return response;

	}

	@PostMapping("/employee")
	public EmployeeResponse addData(@RequestBody Employee employee) {
		EmployeeResponse response = new EmployeeResponse();
		if (service.addData(employee)) {

			response.setDescription("data added successfully");
			response.setMsg("success");
			response.setEmployee(employee);

		} else {
			response.setDescription("something went wrong");
			response.setMsg("failure");
			response.setStatus(404);
		}
		return response;
	}

}
