package com.te.springrest;

public class App {

}
