package com.te.springrest.beans;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "msg", "description" })
public class EmployeeResponse {

	private int status;
	private String description;
	private String msg;

	@Autowired
	private Employee employee;

	@Autowired
	private List<Employee> employees;

}
