package com.te.springrest.dao;

import java.util.List;

import com.te.springrest.beans.Employee;

public interface EmployeeDao {

	public Employee getData(int id);

	public boolean deleteData(int id);

	public boolean addData(Employee employee);

	public boolean updateData(int id, Employee employee);

	public List<Employee> seeAll();

}
