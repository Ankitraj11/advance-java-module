package com.te.springcore.beans;

import java.io.Serializable;

import lombok.Data;
@Data
public class Department implements Serializable {

	private int deptId;
	private String deptName;
	
	
}
