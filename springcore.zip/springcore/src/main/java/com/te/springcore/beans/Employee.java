package com.te.springcore.beans;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Qualifier;

import lombok.Data;
@Data
public class Employee implements Serializable {

	private int empId;
	private String empName;
	
	private Department department;
	


	public Employee(Department department) {
		super();
		this.department = department;
	}
	
	
	
}
