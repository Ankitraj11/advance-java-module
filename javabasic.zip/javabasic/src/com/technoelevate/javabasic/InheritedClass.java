package com.technoelevate.javabasic;

public class InheritedClass extends InheritanceExample {
       int i=20;
       @Override
       public void m1() {
    	  System.out.println("m1 in inherited class");   
       }
     // public void m1() {
    	//   System.out.println("m1 in inherited class");
     //  }
}
