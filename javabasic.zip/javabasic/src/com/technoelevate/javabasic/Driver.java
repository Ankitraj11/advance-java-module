package com.technoelevate.javabasic;

public class Driver {
	public void drive(Car car) {
		car.start();
		car.accelerate();
		car.brake();
		car.gps();
	}

}
