package com.technoelevate.javabasic;

public class InheritanceExample {

	int i=0;
	public  void m1()
	{
		System.out.println("static method m1");
	}
}
