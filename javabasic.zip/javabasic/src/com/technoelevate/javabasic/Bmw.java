package com.technoelevate.javabasic;

public class Bmw implements Car {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("bmw is started");
	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("bmw is accelereting");

	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println("bmw applies brake");

	}

}
