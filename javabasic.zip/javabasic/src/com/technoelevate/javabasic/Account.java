package com.technoelevate.javabasic;

public class Account {
       double balance=20000;
	
	   public Account( ){
		
	   }
	   
	   public  void withDrawl(double amount) throws InsufficientBalance{
		        
		   if(amount<=balance) {
			   balance=balance-amount;
			   System.out.println("withdrawal amount="+amount);
			   System.out.println("remaining balace"+balance);
			   
		   }
		   else {
			   
			 //  System.out.println("Insufficient balance");
			   throw new InsufficientBalance("Insufficient balance");
		   }
		   
	   }
}
