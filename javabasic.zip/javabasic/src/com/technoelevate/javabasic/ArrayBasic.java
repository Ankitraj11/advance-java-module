package com.technoelevate.javabasic;

import java.util.Arrays;

public class ArrayBasic {

	public static void main(String[] args) {
		int[] array = { 10, 12, 13, 14, 15 };
		int[] arr = new int[5];
		for (int i = 0; i < array.length; i++) {
			arr[i] = array[i];
			System.out.println(arr[i]);

		      
		
		}
		System.arraycopy(array,0,arr,0,array.length);
		System.out.println(Arrays.toString(arr));
		

	}
}
