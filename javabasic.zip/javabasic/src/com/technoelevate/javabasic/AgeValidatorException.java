package com.technoelevate.javabasic;

public class AgeValidatorException  extends RuntimeException{

	   public AgeValidatorException( String msg)
	   {
		   super(msg);
	   }
}
