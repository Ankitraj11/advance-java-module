package com.technoelevate.javabasic;
import java.util.Scanner;
public class CarFactory {

	public static Car getCar()
	{
		Scanner scanner=new Scanner(System.in);
		System.out.println("enter the name of car");
		String carName=scanner.next();
		
		if(carName.equalsIgnoreCase("bmw")) {
			return new Bmw();
		}
		else if(carName.equalsIgnoreCase("benz")) {
			return new Benz();
		}
		else if(carName.equalsIgnoreCase("audi")) {
			return new Audi();
		}
		return  null;
	}
	

}
