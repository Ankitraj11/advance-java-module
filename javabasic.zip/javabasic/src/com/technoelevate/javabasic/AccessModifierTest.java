package com.technoelevate.javabasic;

public class AccessModifierTest {

	public static void main(String[] args) {
		AccessModifierExample accessModifierExample=new AccessModifierExample();
		accessModifierExample.getPublic();
		accessModifierExample.getProtected();
		accessModifierExample.getDefault();
		
	
		
	}
	
}
