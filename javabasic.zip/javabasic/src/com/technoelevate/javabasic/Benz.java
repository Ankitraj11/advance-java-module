package com.technoelevate.javabasic;

public class Benz implements Car {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("benz started");

	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("benz accelerate");

	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println("benz applied brake");

	}

}
