package com.technoelevate.javabasic;

public class Audi  implements Car{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.out.println("audi is starting");
		
	}

	@Override
	public void accelerate() {
		// TODO Auto-generated method stub
		System.out.println("audi is accelerating");
	}

	@Override
	public void brake() {
		// TODO Auto-generated method stub
		System.out.println("audi applies brake");
	}

}
