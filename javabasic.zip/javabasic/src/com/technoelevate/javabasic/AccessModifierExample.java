package com.technoelevate.javabasic;

public class AccessModifierExample {

	public void getPublic() {
		System.out.println("public method");
	}

	protected void getProtected() {
		System.out.println("protected method");
	}

	void getDefault() {
		System.out.println("Default method");
	}

	private void getPrivate() {
		System.out.println("Private method");
	}
    
	public static void main(String[] args) {
		AccessModifierExample accessModifierExample=new AccessModifierExample();
		accessModifierExample.getPrivate();
		accessModifierExample.getDefault();
		
	}
}
