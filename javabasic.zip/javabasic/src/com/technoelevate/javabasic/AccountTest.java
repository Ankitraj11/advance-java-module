package com.technoelevate.javabasic;

import java.util.Scanner;

public class AccountTest {
   public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	  Account account=new Account(); 
	double amount=scanner.nextDouble();
	 
	  
	try{
	     account.withDrawl(amount);
	     
		
	  }
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
	
	
	
}
}
