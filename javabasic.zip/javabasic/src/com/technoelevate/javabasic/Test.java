package com.technoelevate.javabasic;

public class Test {
        public static void main(String[] args)
        {
        	InheritanceExample example=new InheritedClass();
        	example.m1();
        	System.out.println(example.i);
        }
}
