package com.technoelevate.javabasic;

public class CarTest {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Car car=CarFactory.getCar();
		Driver driver =new Driver();
		driver.drive(car);
		
	}

}
