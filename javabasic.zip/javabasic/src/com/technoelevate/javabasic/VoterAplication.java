package com.technoelevate.javabasic;
import java.util.Scanner;
public class VoterAplication {

	 public void vote()
	 {
		  Scanner scanner =new Scanner(System.in);
		  System.out.println("enter your age");
	   int age=scanner.nextInt();	  
	 
	     if(age>=18)
	     {
	    	 System.out.println("vote casted successsfuly");
	     }
	     else {
	    	 throw new AgeValidatorException("not eligible for voting");
	     }
	 }
}
