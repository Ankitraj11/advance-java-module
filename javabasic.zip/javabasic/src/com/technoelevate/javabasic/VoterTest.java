package com.technoelevate.javabasic;

public class VoterTest {

	public static void main(String[] args) {
		VoterAplication aplication =new VoterAplication();
		try {
			aplication.vote();
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
