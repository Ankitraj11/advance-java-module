package com.te.studentwebapp;

public class App {

}
