package com.te.studentwebapp.servicce;

public interface StudentService {

	
}
