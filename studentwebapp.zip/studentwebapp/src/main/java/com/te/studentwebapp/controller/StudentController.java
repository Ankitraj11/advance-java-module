package com.te.studentwebapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {

	@RequestMapping(path="/login")
	public String login() {
		return "login";
	}
	
	
}
