package com.te.studentwebapp.dao;


public interface StudentDao {

   	public void authenicate(int id,String password);
	
}
