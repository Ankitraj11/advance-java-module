package com.te.studentwebapp.beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Entity
@Data
@Table(name="student")
public class Student implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="student_id")
	private int studentId;
	@Column(name="student_name")
	private String studentName;
	@Column(name="student_std")
	private String studentStd;
	@Column(name="student_gender")
	private String studentGender;
	@Column(name="student_age")
	private String studentAge;
	@Column(name="student_email")
	private String studentEmail;
	@Column(name="student_password")
	private String studentPassword;
	
	
	
	
	
	
	
}
