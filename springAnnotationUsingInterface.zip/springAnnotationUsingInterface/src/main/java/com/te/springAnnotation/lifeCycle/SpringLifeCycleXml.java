package com.te.springAnnotation.lifeCycle;

import lombok.Data;

public class SpringLifeCycleXml {

	private int id;
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		System.out.println("Inside setter id");
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("inside name seter");
		this.name = name;
	}

	public void init() {
		System.out.println("Inside start");
	}

	public void destroy() {
		System.out.println("inside destroy");
	}

}
