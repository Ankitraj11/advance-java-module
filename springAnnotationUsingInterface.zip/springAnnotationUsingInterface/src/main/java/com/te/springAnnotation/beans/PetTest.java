package com.te.springAnnotation.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.te.springAnnotation.config.AllConfig;

public class PetTest {

	public static void main(String[] args) {
		ApplicationContext context=new AnnotationConfigApplicationContext(AllConfig.class);
		Pet pet=(Pet) context.getBean("getPet");
		System.out.println(pet.getP_name());
		pet.getAnimal().bark();
		pet.getAnimal().eat();
		
	}
}
