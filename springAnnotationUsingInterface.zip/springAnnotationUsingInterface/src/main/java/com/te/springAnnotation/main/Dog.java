package com.te.springAnnotation.main;

public class Dog  implements Animal{

	@Override
	public void bark() {
		System.out.println("dog is barking");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("dog is eatinf chicken");
	}

}
