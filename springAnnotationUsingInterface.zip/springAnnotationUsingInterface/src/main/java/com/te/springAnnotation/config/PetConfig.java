package com.te.springAnnotation.config;

import org.springframework.context.annotation.Bean;

import com.te.springAnnotation.beans.Pet;

public class PetConfig {

	@Bean
	public Pet getPet() {
		Pet pet=new Pet();
		pet.setP_name("Bruno");
		return pet;
	}
	
	@Bean
	public Pet getPet1() {
		Pet pet=new Pet();
		pet.setP_name("Bingo");
		return pet;
		
		
	}
}
