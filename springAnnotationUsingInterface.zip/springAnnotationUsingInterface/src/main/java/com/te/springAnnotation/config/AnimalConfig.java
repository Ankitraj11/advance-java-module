package com.te.springAnnotation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.te.springAnnotation.main.Animal;
import com.te.springAnnotation.main.Cat;
import com.te.springAnnotation.main.Dog;

@Configuration
public class AnimalConfig {

	@Bean
	public Animal getCat() {
		Animal animal = new Cat();
		return animal;
	}

	@Bean
	@Primary
	public Animal getDog() {
		Animal animal = new Dog();
		return animal;
	}

}
