package com.te.springAnnotation.main;

public class Cat  implements Animal{

	@Override
	public void bark() {
		// TODO Auto-generated method stub
		System.out.println("cat meows");
		
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("cat eat fish");
	}

}
