package com.te.springAnnotation.main;

public interface Animal {
 void bark();
 void eat();
}
