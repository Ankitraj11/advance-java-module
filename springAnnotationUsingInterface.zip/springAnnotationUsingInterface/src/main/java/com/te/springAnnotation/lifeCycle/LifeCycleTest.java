package com.te.springAnnotation.lifeCycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LifeCycleTest {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("springLifeCycle.xml");
		SpringLifeCycleXml lifeCycleTest = context.getBean("lifecycle", SpringLifeCycleXml.class);
		System.out.println(lifeCycleTest);
		context.close();

	}
}
