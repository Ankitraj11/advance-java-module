package com.te.java.multithreading;

public class MyThreadUsingRunnableTest {

	public static void main(String[] args) {
		
		Runnable runnable=new MyTheadUsingRunnable();
		Thread thread=new Thread(runnable);
		thread.start();
		
		
		
		
	}
}
