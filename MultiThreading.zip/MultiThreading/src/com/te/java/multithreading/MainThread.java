package com.te.java.multithreading;

public class MainThread {

	public static void main(String[] args) {
		
		Thread thread =new MyThread();
		thread.start();
		
		for(char ch ='a'; ch<'h';ch++) {
			System.out.println(ch + "--"+Thread.currentThread().getName());
		    try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
