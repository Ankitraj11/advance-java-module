package jcom.te.lambda;

public class MethodReference {

	public void greeting() {
		System.out.println("hello everyone");
	}
	public MethodReference() {
		System.out.println("from construtor");
	}
	public static void callerTune() {
		System.out.println("Namaste...");
	}
	public static void main(String[] args) {
		
		MethodReference methodReference=new MethodReference();
		Test t=methodReference::greeting;
		t.m1();
		Test t1=MethodReference::callerTune;
		t1.m1();
		Test t2=MethodReference::new;
		t2.m1();
		
	}
}
