package jcom.te.lambda;

public class LambdaExpression {
public static void main(String[] args) {
	Test t=()->{
		System.out.println("from test m1()");
		
		
		
		
	};
	t.m1();
	Runnable runnable=()->{
		for(int i=0;i<5;i++) {
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	};
	Thread thread=new Thread(runnable);
	thread.start();
}
}
