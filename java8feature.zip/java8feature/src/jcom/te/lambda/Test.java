package jcom.te.lambda;

@FunctionalInterface
public interface Test {
void m1();
}
