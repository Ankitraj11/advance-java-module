package jcom.te.java8;

public class Demo  implements Test,Test2{

	

	public static void main(String[] args) {
		Demo demo=new Demo();
		demo.m1();
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		Test.super.m1();
	}

	

	
}
