package jcom.te.java8;

public interface Test {

	default void m1() {
		System.out.println("from m1");
	}
}
