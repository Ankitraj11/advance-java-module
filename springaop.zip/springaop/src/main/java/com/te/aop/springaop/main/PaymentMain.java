package com.te.aop.springaop.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PaymentMain {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("springaop.xml");
		PaymentImpl paymentImpl=context.getBean("payment",PaymentImpl.class);
		paymentImpl.pay();
		
	}
}
