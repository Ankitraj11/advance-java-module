package com.te.aop.springaop.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class MyAspect {

	@Before("execution(* com.te.aop.springaop.main.PaymentImpl.pay())")
	public void beforePayment() {
		System.out.println("Payment started");
		
	}
	
	@After("execution(* com.te.aop.springaop.main.PaymentImpl.pay())")
	public void afterPayment() {
		System.out.println("Payment successfull");
	}
	
}
