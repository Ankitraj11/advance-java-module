package com.te.aop.springaop.main;

public interface Payment {

	
	public void pay(); 
	
}
