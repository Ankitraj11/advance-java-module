package com.te.aop.springaop.main;

public class PaymentImpl implements Payment {

	@Override
	public void pay() {
		// TODO Auto-generated method stub
		System.out.println("payment is going on");
	}

}
