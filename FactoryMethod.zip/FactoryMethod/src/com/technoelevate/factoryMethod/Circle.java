package com.technoelevate.factoryMethod;

public class Circle implements Shape {

	@Override
	public void getShape() {
		// TODO Auto-generated method stub
		System.out.println("shape is circle");
	}

}
