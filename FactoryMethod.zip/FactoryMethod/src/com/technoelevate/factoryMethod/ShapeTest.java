package com.technoelevate.factoryMethod;



public class ShapeTest {

	public void getShape(Shape shape) {
		shape.getShape();
	}
}
