package com.technoelevate.factoryMethod;

public interface Shape {
   
	public abstract void getShape();
}
